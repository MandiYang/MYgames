# Game package info

This is my first simple python package on [PyPi](https://pypi.org/).

You can play some games with this package, currently there are only 2 games by me but I will release more.

I am not a adult and not a native english speaker so the text can be hard to read. You are welcome to suggest improvements or bug fixes.


# Usage

## rock paper and scissors

running on terminal or command prompt:


    python3 -m MYgames.rock_paper_scissors

example output:

```
Welcome to my game, rock, scisscors and paper. 
Choose your weapon below

 rock 
 scissors 
 paper 
: paper
computer:scissors vs you:paper
you loose
play_again? yes/no: no
```

## Memory

running on terminal or command prompt:


    python3 -m MYgames.memory


# LICENSE

## This project is licensed under MIT











