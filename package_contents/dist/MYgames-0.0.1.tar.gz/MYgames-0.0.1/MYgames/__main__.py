print('choose to run rock_paper_scissors or memory game')
