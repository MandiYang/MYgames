__version__='0.0.1'
install_python_version='bigger than 3.5'
def hello():
    print('hi')

